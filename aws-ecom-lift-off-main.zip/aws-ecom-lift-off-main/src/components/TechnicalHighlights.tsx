import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";

const technologies = [
  "Amazon EC2", "Amazon RDS", "Amazon S3", "Amazon CloudFront", "Elastic Load Balancer",
  "Amazon DynamoDB", "AWS Lambda", "Amazon API Gateway", "Amazon CloudWatch", "AWS IAM"
];

const metrics = [
  { label: "Performance Improvement", value: "300%", color: "text-primary" },
  { label: "Cost Reduction", value: "45%", color: "text-aws-orange" },
  { label: "Uptime Achievement", value: "99.9%", color: "text-primary" },
  { label: "Load Time Reduction", value: "65%", color: "text-aws-orange" }
];

const TechnicalHighlights = () => {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold mb-8 text-foreground">
              Technical Excellence
            </h2>
            
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
              Our AWS migration project leverages cutting-edge cloud technologies to deliver 
              exceptional performance and reliability for e-commerce operations.
            </p>
            
            <div className="grid grid-cols-2 gap-6 mb-8">
              {metrics.map((metric, index) => (
                <div key={index} className="text-center">
                  <div className={`text-4xl font-bold ${metric.color} mb-2`}>
                    {metric.value}
                  </div>
                  <div className="text-muted-foreground">
                    {metric.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <Card className="p-8 bg-card-gradient">
            <h3 className="text-2xl font-semibold mb-6 text-card-foreground">
              AWS Technologies Used
            </h3>
            
            <div className="flex flex-wrap gap-3">
              {technologies.map((tech, index) => (
                <Badge 
                  key={index} 
                  variant="secondary" 
                  className="px-4 py-2 text-sm bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
                >
                  {tech}
                </Badge>
              ))}
            </div>
            
            <div className="mt-8 p-6 bg-tech-gradient rounded-lg text-white">
              <h4 className="text-lg font-semibold mb-3">Migration Approach</h4>
              <ul className="space-y-2 text-sm">
                <li>• Lift-and-shift with optimization</li>
                <li>• Microservices architecture implementation</li>
                <li>• Database modernization strategy</li>
                <li>• Security-first design principles</li>
              </ul>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default TechnicalHighlights;