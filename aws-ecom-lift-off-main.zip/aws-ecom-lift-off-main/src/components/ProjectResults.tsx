import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, TrendingUp, Users, Zap } from "lucide-react";

const results = [
  {
    icon: CheckCircle,
    title: "Successful Migration",
    description: "Complete migration of e-commerce platform to AWS with zero downtime during transition."
  },
  {
    icon: TrendingUp,
    title: "Performance Gains",
    description: "Achieved 300% improvement in application performance and 65% reduction in page load times."
  },
  {
    icon: Users,
    title: "Enhanced User Experience",
    description: "Streamlined checkout process resulted in 25% increase in conversion rates."
  },
  {
    icon: Zap,
    title: "Scalability Success",
    description: "Auto-scaling handled 500% traffic increase during Black Friday without issues."
  }
];

const ProjectResults = () => {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
            Project Results
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            The AWS migration project delivered exceptional results, transforming the e-commerce 
            platform's performance, reliability, and user experience.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {results.map((result, index) => (
            <Card key={index} className="p-8 bg-card-gradient border-border hover:shadow-lg transition-all duration-300 group">
              <div className="flex items-start space-x-4">
                <div className="p-3 bg-tech-gradient rounded-lg group-hover:scale-110 transition-transform duration-300">
                  <result.icon className="w-6 h-6 text-white" />
                </div>
                
                <div className="flex-1">
                  <h3 className="text-xl font-semibold mb-3 text-card-foreground">
                    {result.title}
                  </h3>
                  
                  <p className="text-muted-foreground leading-relaxed">
                    {result.description}
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>
        
        <div className="text-center">
          <Card className="inline-block p-8 bg-hero-gradient text-white">
            <h3 className="text-2xl font-bold mb-4">Ready to Learn More?</h3>
            <p className="mb-6 text-white/90">
              Explore the detailed technical documentation and implementation guide.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-primary">
                View Documentation
              </Button>
              <Button variant="aws" size="lg">
                Contact Team
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default ProjectResults;