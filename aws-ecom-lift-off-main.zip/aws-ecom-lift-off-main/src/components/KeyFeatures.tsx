import { Card } from "@/components/ui/card";
import { Cloud, Shield, Zap, Database, CreditCard, BarChart3 } from "lucide-react";

const features = [
  {
    icon: Cloud,
    title: "AWS Cloud Migration",
    description: "Seamless migration of e-commerce infrastructure to AWS cloud services for enhanced performance and reliability."
  },
  {
    icon: Zap,
    title: "Scalability Optimization",
    description: "Auto-scaling solutions that handle traffic spikes during peak shopping seasons and promotional events."
  },
  {
    icon: Shield,
    title: "Enhanced Reliability",
    description: "Multi-region deployment with failover capabilities ensuring 99.9% uptime for critical e-commerce operations."
  },
  {
    icon: CreditCard,
    title: "Checkout Process Optimization",
    description: "Streamlined checkout flow reducing cart abandonment rates and improving customer conversion."
  },
  {
    icon: Database,
    title: "Data Storage Solutions",
    description: "Optimized database architecture with Amazon RDS and DynamoDB for fast product catalog and order processing."
  },
  {
    icon: BarChart3,
    title: "Performance Analytics",
    description: "Real-time monitoring and analytics to track migration success and system performance metrics."
  }
];

const KeyFeatures = () => {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
            Key Project Features
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Comprehensive AWS migration solution designed to transform e-commerce infrastructure 
            with focus on performance, reliability, and scalability.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="p-8 bg-card-gradient border-border hover:shadow-lg transition-all duration-300 group">
              <div className="flex flex-col items-start">
                <div className="p-3 bg-tech-gradient rounded-lg mb-6 group-hover:scale-110 transition-transform duration-300">
                  <feature.icon className="w-8 h-8 text-white" />
                </div>
                
                <h3 className="text-2xl font-semibold mb-4 text-card-foreground">
                  {feature.title}
                </h3>
                
                <p className="text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default KeyFeatures;