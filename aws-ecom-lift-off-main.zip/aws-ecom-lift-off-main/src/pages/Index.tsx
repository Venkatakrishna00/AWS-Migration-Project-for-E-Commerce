import HeroSection from "@/components/HeroSection";
import KeyFeatures from "@/components/KeyFeatures";
import TechnicalHighlights from "@/components/TechnicalHighlights";
import ProjectResults from "@/components/ProjectResults";

const Index = () => {
  return (
    <main className="min-h-screen">
      <HeroSection />
      <KeyFeatures />
      <TechnicalHighlights />
      <ProjectResults />
    </main>
  );
};

export default Index;
